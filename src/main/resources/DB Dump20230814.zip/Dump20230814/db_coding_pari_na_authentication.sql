-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: db_coding_pari_na
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `authentication`
--

DROP TABLE IF EXISTS `authentication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authentication` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(45) NOT NULL,
  `password` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`id`,`email`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication`
--

LOCK TABLES `authentication` WRITE;
/*!40000 ALTER TABLE `authentication` DISABLE KEYS */;
INSERT INTO `authentication` VALUES (3,'ibrahimhossaincse@gmail.com','$2a$10$98YYgE7vFpLJZjvWtc8z7eLhJyouutiqAlYynwc7gCYyw.BrN5X.C'),(7,'ibrahimhossain88@gmail.com','$2a$10$sZCXfg8ixgbA4utnDUnBMOniqVYCv0D5uJ.JFmh77cs.ibLWjjInW'),(9,'ibrahimhossain00@gmail.com','$2a$10$62dhgwfbT9QpUWAQKJeQW.4/14gUuAcFKsHzSbIkASvonjD/Mrt8G'),(10,'mdabusayedsany20@gmail.com','$2a$10$wufcmb/LNeBZ7QpvNzqbzesrhAGmJEKGoeMKaUot82qJ./3RTbn7.'),(11,'ibrahimjewel@gmail.com','$2a$10$KikeUixp6piTEG0v0evroeTY8lb51hLRfnLdzSMgsvYzzjkcDdKG2'),(12,'ibrahimman@gmail.com','$2a$10$.zIovrKGtvvDgtgCm/nAsOvWmJZUHdFs9jeKTNrcY1lUEd3eMSwmW'),(13,'ibrahimm1an@gmail.com','$2a$10$RYTqZuQE8BmwHO0sdRduZet41fNod3OdfO0HE/lRH/9or.uhN6WNa'),(14,'sany@gmail.com','$2a$10$NlXpZcAEEnR6edxGYmgVAu3YR/CIfjZS1qaOopUrmP02LHyv1OgOO'),(15,'ibrahim@gmail.com','$2a$10$HzwElPJ6uhQMdcqulA62N.ibGXgQkZOVRr9jBjt.VX8WH/A3.fA8K'),(16,'jewel@gmail.com','$2a$10$l6V6m1NRFM2VD./cxN566OPfCH.UD0Iw3M9.5IkjtIhpardxkpC16'),(17,'ibrahimman11@gmail.com','$2a$10$GWkqpKpO0Tgvwhj5B0UXzePV2JuGyS1AUzJ8oVnWPn4Rlb6UNGL0m'),(18,'ibrahimman1@gmail.com','$2a$10$lydMqw0yHbui2MBqtGWVCuMjGOENSpwySbR0dxvGnyJqjG4NUKYme'),(19,'ibrahim1@gmail.com','$2a$10$w5Nn/JEQNcsw6UGaC8DnOuP4jx0ORcq9ofcizEGp.ltFNvISd/nrC'),(20,'ibrahim2@gmail.com','$2a$10$1/sNCMJ9bSREooZvEC5V6.r.XpQNmEkwLJM3wISKN.1AWocJgT8xW'),(21,'ibrahimman3@gmail.com','$2a$10$qo421874z.xAoABiF6EUqu9Ap37wqLvQWy6h7JYjWPFUr360DKnQ.'),(22,'ibrahimman4@gmail.com','$2a$10$hAUo5AUP1prhnAP5tpClN.e63pvZ/QaFn9043wMKRVYKnrkbG4NQO'),(23,'ibrahimman5@gmail.com','$2a$10$FmptSO1XZ9X/vTAqYMnhquB2sodGu7udmb9oAYa.cOSvisPe7X/Qm'),(24,'ibrahimman7@gmail.com','$2a$10$nTfjNqF.KLOCEr7iLW9zwutk0FgpM0x0PL5gvBH3PsQWmZvmDgfpa'),(25,'ibrahim9@gmail.com','$2a$10$YAymF2o.q0elkIqRl9cvw.58heGB3YYNCA4a8QRrQCl9OB876gH/e'),(26,'ibrahimman99@gmail.com','$2a$10$Sjqglfb8ndkICjDj59IzhOxHmwdPnC0MKsfEIeylzkgRR5rqCPXxK'),(27,'ibrahimman9@gmail.com','$2a$10$0NqSTQcy9rPXB0QRCi221emYb0HM4IBgy.MoZun3/GrcyjiEA8GMC'),(28,'ibrahimman111@gmail.com','$2a$10$0FtWW8is1g.h1jkhPEv6peA5wjQwuWG6g5PPA8DJBl7pJN181sPRu'),(29,'Sany20@gmail.com','$2a$10$5X0WLUPVZkGbCG0NyJXYfuZesIMrbugRFGHPddqviuIUAb09ZhR2O'),(30,'ibrahimman@gmail.comm','$2a$10$vyUJjAVDyXomS5dUiL3QDeNr7r0wXrJn5/zGNE.OcjpdarrZeyC5i');
/*!40000 ALTER TABLE `authentication` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-14 22:15:23
